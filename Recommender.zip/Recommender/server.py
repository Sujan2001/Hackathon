# -*- coding: utf-8 -*-
"""
Created on Wed Mar 22 16:46:40 2023

@author: abhishek.sn
"""

from flask import Flask, render_template, json, request, jsonify
from flask_socketio import SocketIO, emit,join_room, leave_room
import io
from PIL import Image
import base64, cv2

import numpy as np
import pandas as pd
import pandasql as ps
from sqlalchemy import text

app = Flask(__name__)
df = pd.read_csv("plans.csv",header=0)
def filt(typ,data):
    #query = "select * from df where "+condition
    i = 0
    arr = []
    for ind in df.index:
        if str(df['Type'][ind]) == typ and str(df['Data'][ind]) == data:
            arr.append({'size':str(df.iloc[[ind]]['Data'].values[0]), 'valid':str(df.iloc[[ind]]['Validity'].values[0]), 'rate':str(df.iloc[[ind]]['Amount'].values[0])})
            print(arr)
    #res =  ps.sqldf()(text(query), globals())
    return {'value':arr}    
@app.route('/', methods=['POST', 'GET'])
def index():
    return render_template('index.html')
    print("page opened", flush=True)
#@socketio.on('img')
@app.route('/plans', methods=['POST'])
def query():
    typ = request.form['Type'] 
    data = request.form['size']
    print(typ,data)
    res = filt(typ,data)
    #return(query)
    return json.dumps(res)
    
if __name__ == '__main__':
    socketio.run(app, port=9990, debug=True)
    
    
    