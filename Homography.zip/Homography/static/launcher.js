const launcher = function() {
	const _config = {
		dcCloundfrontDomain : "https://d2j8jkom7xmn9n.cloudfront.net",
		awsCloundfrontDomain : "https://canvas-dev-cdn.cac.247-inc.net",
		crsConfig : {
			crsUrl : "https://staging.api.247-inc.net", // env specific
			apiKey : "UojPvBy7wy2a60fBDN9dcVHinI9W48f2"
		},
		secureCardProxyConfig: {
			"baseUrl": "https://staging.api.247-inc.net/v1",
			"apiKey": "NVjuERGATb9uoQEd9QUpC9TCZzVcFCsd"
		},
		secureCardsHtmlPath : "https://d2j8jkom7xmn9n.cloudfront.net/frontends/files/cards.html",
		activeCardsHtmlPath : "https://canvas-dev-cdn.cac.247-inc.net/player/activecard/latest/anchor.html",
		instanceId : '',
		interactionId : '',
		userId : null,
		iframeConfig : {
			elem : null,
			iframeContainer : document.body,
			iframeElem : null,
			windowRef : window,
			height : "800",
			width : "500",
			modalContentContainer : null,
			modalContainer : null,
		},
		modalControlType : "external", // might need to make it "internal" after AFV integration
		windowConfig : {
			windowInstance : null,
			windowRef : window,
		},
		explicitListener : null,
		autoInit : true,
		cardTarget : "modal", // <modal/newtab>
		sessionInfo : {},
		metaData : {},
		libVersion : '3.0'
	}

	const getCardConfig = function() {
		const config = {
      "systemMessage": "",
      "isExternal": true,
      "isPCF": false,
      "name": "",
      "invoke": {
        "auto": true,
        "delay": "100",
        "title": ""
      },
      "isCES": false,
      "type": "sliding",
      "confidential": _config.confidential,
			"secureStorageModes": [],
      "viewArgs" : {
				"linkedCardLauncherType": "external",
				"readOnly":	false,
				"accountId": _config.accountId,
				"clientId": _config.clientId,
				"agentView": false,
				"cardId": _config.cardId,
				"name": _config.cardName,
				"env": _config.env,
				"type": "Canvas Slider",
				"orgId": _config.orgId,
				"version": _config.version,
				"channel": getServiceChannelCode(_config.metaData && _config.metaData.serviceChannel),
				"logger":true,
				"url": _config.anchorUrl, 
				"data": _config.cardData,
				"processOnServer": false,
				"confidential": _config.confidential,
				"libVersion": _config.libVersion || '3.0'
			},
		}
		if(_config.sessionInfo && _config.sessionInfo.storageMode) {
			config.secureStorageModes = _config.sessionInfo.storageMode
		}

		return config
	}

	const postMessageListener = function(e) {
		if(e && e.data) {
			let eventData
			const meta = _config.metaData || {}
			try {
				eventData = JSON.parse(e.data)
			} catch(e) {
				eventData = {}
			}
			if(eventData && eventData.name && eventData.instanceId == _config.instanceId) {
				eventData["meta"] = {
					...meta
				}
				switch(eventData.name) {
					case "frame.ready": {
    				const iframeElem = _config.iframeConfig.iframeElem
    				iframeElem && iframeElem.contentWindow && iframeElem.contentWindow.postMessage(JSON.stringify({
					  	name: 'frame.card.config',
					  	instanceId: _config.instanceId,
					  	data: {
						    appConfig: {
									"secureCardProxyConfig": _config.secureCardProxyConfig
								},
						    cardConfig: getCardConfig(),
						    context: {},
								sessionInfo: _config.sessionInfo
						  }
						}), "*")
						_config.explicitListener && _config.explicitListener.onViewReady && _config.explicitListener.onViewReady(eventData)
						break;
    			}

					case "frame.error" : {
						_config.explicitListener && _config.explicitListener.onFrameError && _config.explicitListener.onFrameError(eventData)
						if(_config.modalControlType == "internal") {
							closeInternalInstance()
						}
						break;
					}

					case "frame.dimensions" : {
						break;
					}

					case "frame.card.submit" : {
						_config.explicitListener && _config.explicitListener.onSubmit && _config.explicitListener.onSubmit(eventData)
						if(_config.modalControlType == "internal") {
							closeInternalInstance()
						}
						break;
					}

					case "frame.card.cancel" : {
						_config.explicitListener && _config.explicitListener.onCancel && _config.explicitListener.onCancel(eventData)
						if(_config.modalControlType == "internal") {
							closeInternalInstance()
						}
						break;
					}

					case "frame.card.error" : {
						_config.explicitListener && _config.explicitListener.onCardError && _config.explicitListener.onCardError(eventData)
						if(_config.modalControlType == "internal") {
							closeInternalInstance()
						}
						break;
					}

					default : {

					}
				}
			}
		}
	}

	const getActionTypeCode = (actionType) => {
		const map = {
			submit : 'submit',
			cancel : 'cancel',
			error : 'error'
		}
		return map[actionType] || 'any'
	}

	const getEventName = (actionType) => {
		switch(actionType) {
			case "submit":
				return "frame.card.submit"

			case "cancel":
				return "frame.card.cancel"

			case "error":
				return "frame.card.error"

			default:
				return "default"
		}
	}

	this.getCallbackData = function (eventData, actionType = 'any', message = '') {
		let callbackData = {}
		if(eventData) {
			callbackData = { ...eventData }
		} else {
			callbackData = {
				data : {
					formData : {}
				},
				instanceId : _config.instanceId,
				meta : _config.metaData,
				name : getEventName(actionType)
			}
		}
		callbackData.callbackData = {
			eventType : getActionTypeCode(actionType),
			linkedWidgetId : _config.metaData && _config.metaData.parentCardLinkedWidgetId || '',
			message
		}
		if(actionType == "error" && callbackData && callbackData.data && callbackData.data.errorMessage) {
			callbackData.data.formData = { errorMessage : callbackData.data.errorMessage }
		}
		return callbackData
	}

	this.loadCard = function() {
		let instanceElem = null, windowRef = null, source = ''
		const htmlPath = _config.confidential ? _config.secureCardsHtmlPath : _config.activeCardsHtmlPath
		if(_config.cardTarget == "modal") {
			if(_config.modalControlType && _config.modalControlType == "internal") {
				constructModalContainer()
			}
			windowRef = _config.iframeConfig.windowRef || window
			source = `${htmlPath}?origin=${windowRef.location.origin}&instanceId=${_config.instanceId}`
			instanceElem = windowRef.document.createElement('iframe')
			instanceElem.src = source
			instanceElem.id = "iframeRef-" + _config.interactionId
			instanceElem.width = "100%"
			instanceElem.height = "100%"
			instanceElem.style.border = "0"
			_config.iframeConfig.iframeElem = instanceElem
			windowRef.addEventListener("message", postMessageListener)
			if(_config.modalControlType && _config.modalControlType == "internal" && _config.iframeConfig.modalContentContainer) {
				_config.iframeConfig.modalContentContainer.appendChild(instanceElem)
			} else {
				_config.iframeConfig && _config.iframeConfig.iframeContainer && _config.iframeConfig.iframeContainer.appendChild(instanceElem)
			}
		} else if(_config.cardTarget == "newtab") {
			windowRef = _config.windowConfig.windowRef || window
			source = `${htmlPath}?origin=${windowRef.location.origin}&instanceId=${_config.instanceId}`
			instanceElem = window.open(source, "_blank", "")
			_config.windowConfig.windowInstance = instanceElem
			windowRef.addEventListener("message", postMessageListener)
		}
		return instanceElem
	}

	this.close = function() {
		let windowRef = null
		if(_config.cardTarget == "modal") {
			const iframeElem = _config.iframeConfig.iframeElem
			windowRef = _config.iframeConfig.windowRef || window 
			if(iframeElem && iframeElem.parentNode) {
				iframeElem.parentNode.removeChild(iframeElem)
				_config.iframeConfig.iframeElem = null
			}
			windowRef.removeEventListener("message", postMessageListener)
		} else {
			const windowInstance = _config.windowConfig && _config.windowConfig.windowInstance
			windowRef = _config.iframeConfig.windowRef || window 
			if(windowInstance) {
				windowInstance.close()
			}
			windowRef.removeEventListener("message", postMessageListener)
		}
	}

	this.loadWindow = function() {
		this.loadCard()
	}

	this.closeWindow = function() {
		this.close()
	}

	this.loadIframe = function() {
		this.loadCard()
	}

	this.closeIframe = function() {
		this.close()
	}

	this.getCancelActionData = function() {
		return {}
	}

	const closeInternalInstance = () => {
		this.close()
		if(_config.cardTarget == "modal") {
			const modalContainer =_config.iframeConfig.modalContainer
			modalContainer && modalContainer.parentNode.removeChild(modalContainer)
		}
	}

	const generateModalDimensions = () => {
		const windowInstance = _config.iframeConfig.windowRef || window
		const windowWidth = Number(windowInstance.innerWidth)
		const windowHeight = Number(windowInstance.innerHeight)
		const dimensions = {
			height : _config.iframeConfig.height,
			width : _config.iframeConfig.width
		}
		const heightUnit =  _config.iframeConfig.width.indexOf("%") == -1 ? "px" : "%"
		const widthUnit =  _config.iframeConfig.width.indexOf("%") == -1 ? "px" : "%"
		let heightValue =  heightUnit == "%" ? Number(_config.iframeConfig.height.split("%")[0]) : Number(_config.iframeConfig.height.split("px")[0])
		let widthValue =  widthUnit == "%" ? Number(_config.iframeConfig.width.split("%")[0]) : Number(_config.iframeConfig.width.split("px")[0])
		
		if(widthUnit == "%") {
			widthValue = windowWidth * (widthValue / 100)
			
		} 
		if(widthValue > windowWidth) {
			dimensions.width = windowWidth
		}
		if(heightUnit == "%") {
			heightValue = windowHeight * (heightValue / 100)
			
		} 
		if(heightValue > windowHeight) {
			dimensions.height = windowHeight
		}
		return dimensions
	}

	const constructModalContainer = () => {
		const modalContainer = document.createElement('div')
		modalContainer.id = "linkCardModalContainer"
		const modalOverLay = document.createElement('div')
		const modalContentContainer = document.createElement('div')
		const modalContent = document.createElement('div')
		const modalCloseButton = document.createElement('div')
		modalCloseButton.innerText = "x"
		modalCloseButton.onclick = () => {
			const meta = _config.metaData || {}
			const	eventData = {
					meta
				}
			_config.explicitListener && _config.explicitListener.onCancel && _config.explicitListener.onCancel(eventData)
			closeInternalInstance()
		}
		modalContainer.appendChild(modalOverLay)
		modalContainer.appendChild(modalContentContainer)
		modalContentContainer.appendChild(modalContent)
		modalContentContainer.appendChild(modalCloseButton)
		_config.iframeConfig.modalContentContainer = modalContent
		_config.iframeConfig.modalContainer = modalContainer

		const dimensions = generateModalDimensions()

		modalOverLay.style.cssText = `
			opacity: 0.5;
			position: fixed;
			left: 0px;
			top: 0px;
			z-index: 1001;
			background-color: #000;
			width: 100vw !important;
			font-size: 12px;
			overflow: hidden !important;
			height: 100vh !important;
		`;
		modalContentContainer.style.cssText = `
			position: fixed;
			height: ${dimensions.height}; 
			width: ${dimensions.width};
			z-index: 1002;
			margin: auto;
			inset: 0;
		`;
		modalCloseButton.style.cssText = `
			width: 12px;
			height: 12px;
			display: inline;
			z-index: 3200;
			position: absolute;
			top: -2%;
			right: 3%;
			cursor: pointer;
			margin-top: 20px;
		`;
		modalContainer.style.cssText = `
			width : 100%;
			height : 100%;
		`;
		modalContent.style.cssText = `
			width : 100%;
			height : 100%;
			background : #ffffff;
		`;
		_config.iframeConfig.iframeContainer.appendChild(modalContainer)
	}

	const getServiceChannelCode = (channel = '') => {
		if(channel) {
			const channelMap = {
				"ACTIVE_SHARE" : "active_share",
				"CHAT" : "chat",
				"AIVA" : "aiva"
			}
			if(channelMap[channel]) {
				return channelMap[channel]
			}
		}
		return 'default'
	}

	const updateConfigFromData = (config) => {
		_config.cardMeta = config.cardMeta || {}
		_config.cardId = config.cardConfig && config.cardConfig.cardId || ""
		_config.clientId = config.cardConfig && config.cardConfig.clientId || ""
		_config.accountId = config.cardConfig && config.cardConfig.accountId || ""
		_config.env = config.cardConfig && config.cardConfig.env || "stg"
		_config.version = config.cardConfig && config.cardConfig.version || ""
		_config.cardName = config.cardConfig && config.cardConfig.name || ""
		_config.orgId = config.cardConfig && config.cardConfig.orgId || ""
		_config.anchorUrl = config.cardConfig && config.cardConfig.url
		_config.confidential = config.cardConfig && config.cardConfig.confidential || false
		_config.cardData = config.cardConfig && config.cardConfig.cardData || {}
		_config.instanceId = config.meta && config.meta.instanceId || ""
		_config.interactionId = config.meta && config.meta.interactionId || ""
		_config.cardTarget = config.containerConfig && (config.containerConfig.target == "newtab" ? "newtab" : "modal") || "modal"
		_config.modalControlType = config.settings && config.settings.modalControlType || "external" // TODO : might need to make it "internal" after AFV integration
		_config.metaData = config.meta || {}
		_config.metaData.confidential = _config.confidential
		_config.libVersion = config.cardConfig && config.cardConfig.libVersion || '3.0'

		if(_config.cardTarget == "modal") {
			_config.iframeConfig.windowRef = config.containerConfig && config.containerConfig.windowRef || window
			_config.iframeConfig.iframeContainer = config.containerConfig && config.containerConfig.iframeContainer || window.document.body
			_config.iframeConfig.width = config.containerConfig && config.containerConfig.width || "500"
			_config.iframeConfig.height =config.containerConfig && config.containerConfig.height || "800"
		} else if(_config.cardTarget == "newtab") {
			_config.windowConfig.windowRef = config.containerConfig && config.containerConfig.windowRef || window
		}
		if(config.eventHandlers) {
			_config.explicitListener = config.eventHandlers
		}
		if(config && config.settings && 'autoLoadCard' in config.settings) {
			_config.autoInit = config.settings.autoLoadCard
		}
		_config.sessionInfo = {
			interactionId: _config.interactionId,
			serviceChannel: getServiceChannelCode(_config.metaData && _config.metaData.serviceChannel),
			userType: 'visitor',
			clientId: _config.clientId,
			unifiedClientId: _config.clientId,
			userId: _config.userId || _config.interactionId
		}
		if(config.meta && config.meta.secureStorageModes) {
			_config.sessionInfo.storageMode = config.meta.secureStorageModes
		}
	}

	function fetchCardDetails(config, callback) {
		const environment = config.cardConfig.env == "prod" ? "live" : "test"
		const apiUrl = `${_config.crsConfig.crsUrl}/crs/v1/clients/${config.cardConfig.clientId}/accounts/${config.cardConfig.accountId}/activecards/name/${config.cardConfig.name}?channel=${config.meta.serviceChannel}&view=${environment}`
		const options = {
			method: 'GET',
			cache: 'no-cache',
			headers: {
        'apikey': _config.crsConfig.apiKey,
        'Content-Type': 'application/json'
      },
		}
		fetch(apiUrl, options)
		.then((response) => response.json())
		.then((res) => {
			if((res && res.cardId) || (res && res.viewArgs)) {
				config.cardConfig = {
					...config.cardConfig,
					cardId : res.cardId,
					version : res.version || '',
					url : config.meta.serviceChannel !== "ACTIVE_SHARE" ? res.url : config.cardConfig.url // to remove maybe
				}

				if(res.secureStorageModes) {
					config.meta.secureStorageModes = res.secureStorageModes
				}
				if("confidential" in res) {
					config.cardConfig.confidential = res.confidential || false
				}

				let viewArgs = {}

				if(config.meta.serviceChannel == "ACTIVE_SHARE" && (!res.confidential || (res.viewArgs && !res.viewArgs.confidential))) {
					viewArgs = res
					if(viewArgs.anchorUrl) {
						config.cardConfig.url = viewArgs.anchorUrl
					}
				} else {
					viewArgs = res.viewArgs ? res.viewArgs : res
					if(viewArgs.anchorUrl) {
						config.cardConfig.url = viewArgs.anchorUrl
					} else if(viewArgs.url && config.meta.serviceChannel != "ACTIVE_SHARE") {
						config.cardConfig.url = viewArgs.url // For ActiveShare Active cards, the html url is stored her, so skipping
					}
				}

				if(viewArgs.publishSettings) {
					try {
						const publishSettings = (typeof viewArgs.publishSettings == "string") ? JSON.parse(viewArgs.publishSettings) : viewArgs.publishSettings
						if(publishSettings && publishSettings.secureStorageModes) {
							config.meta.secureStorageModes = publishSettings.secureStorageModes
						}
					} catch(e) {}
				}

				if(viewArgs.cardId) {
					config.cardConfig.cardId = viewArgs.cardId
				}
				if(viewArgs.orgId) {
					config.cardConfig.orgId = viewArgs.orgId
				}
				if(viewArgs.version) {
					config.cardConfig.version = viewArgs.version
				}
				if(viewArgs.libVersion) {
					config.cardConfig.libVersion = viewArgs.libVersion
				}

				// Fallback for older published cards on Active Share
				if(!config.cardConfig.url && config.meta.serviceChannel == "ACTIVE_SHARE") {
					if(viewArgs.url && viewArgs.url.indexOf("activeShareDesignerAnchor.html") != -1) {
						const urlParams = new URLSearchParams(viewArgs.url);
						const libVersion = urlParams.get('libVersion') || "3.0";
						let confidential = urlParams.get('confidential');
						if(!('confidential' in config.cardConfig)) {
							if(confidential == null ||  confidential == undefined || confidential == "false") {
								confidential = false
							} else if(confidential == "true"){
								confidential = true
							}
							config.cardConfig.confidential = confidential
						}
						if(!config.cardConfig.url) {
							let url
							if(config.cardConfig.confidential || config.cardConfig.confidential == "true") {
								url = `${_config.dcCloundfrontDomain}/canvas/player/activecard/${libVersion}/anchor.js`
							} else {
								url = `${_config.awsCloundfrontDomain}/player/activecard/${libVersion}/anchor.js`
							}
							config.cardConfig.url = url
						}
					}
				}
				
			}
			callback(config)
		})
		.catch((error) => {
			console.log(error)
		})
	}

	this.init = function(config) {
		fetchCardDetails(config, (updatedConfig) => {
			updateConfigFromData(updatedConfig)
			if(_config.autoInit) {
				this.loadCard()
			}
		})
	}

	this.unmount = function() {
		const windowRef = _config.iframeConfig.windowRef || window 
		windowRef.removeEventListener("message", postMessageListener)
	}
}

var setUniqueLauncher = function (config) {
  var launcherKey = 'LAUNCHER_REF' + (window.launcherIndex = (window.launcherIndex || 0) + 1);
  var launcherInstance = eval('' + launcherKey + '= new launcher()');
  if (!config) {
    // config = anchor.anchorUtil.prepareQueryParamsConfig();
  }
  config.launcherRef = launcherKey;
  config.logger = (config && config.logger) ? config.logger : false
  launcherInstance.init(config);
  return launcherInstance
}
window.cardLauncher =  setUniqueLauncher;