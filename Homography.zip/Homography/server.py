# -*- coding: utf-8 -*-
"""
Created on Wed Mar 22 16:46:40 2023

@author: abhishek.sn
"""

from flask import Flask, render_template, json, request, jsonify
from flask_socketio import SocketIO, emit,join_room, leave_room
import time
import io
from PIL import Image
import base64, cv2

import numpy as np
import ast
import json
from json import JSONEncoder
import math

print ("Entering the Flask Server for media processing!!")
kernel = np.ones((5,5))
image_template = [cv2.imread(r"Scene1.png",1),cv2.imread(r"Scene2.png",1),cv2.imread(r"Scene3.png",1)]
sift = cv2.SIFT_create()

points = np.array([(535,50)])
turn_index = 0
threshold = 10
app = Flask(__name__)
node = 0
socketio = SocketIO(app, cors_allowed_origins='*')

def src_pt(node):
    #This piece is to be dirven by conversation designer which is now mocked using a sample driver code
   
    if(node == 1):
        return np.array([(130,51)])
    elif(node == 2):
        return np.array([(150,25)])
    else:
        return np.array([(50,50)])

def homo(img):
    node = node + 1
    src_pt = getSource(node)
    kp1,desc1 = sift.detectAndCompute(image_template[node - 1], None)
    kp2,desc2 = sift.detectAndCompute(img, None)
    FLANN_INDEX_KDTREE = 0
    index_params = dict(algorithm = FLANN_INDEX_KDTREE, trees = 3)
    search_params = dict(checks = 100)
    flann = cv2.FlannBasedMatcher(index_params, search_params)
    matches = flann.knnMatch(descriptors_1, descriptors_2, k=2)
    good_matches = []
    for m,n in matches:
        if m.distance < 0.7 * n.distance:
            good_matches.append(m)
    if len(good_matches) > threshold:
        src_pts = np.float32([keypoints_1[m.queryIdx].pt for m in good_matches]).reshape(-1, 1, 2)
        dst_pts = np.float32([keypoints_2[m.trainIdx].pt for m in good_matches]).reshape(-1, 1, 2)
        M, mask = cv2.findHomography(dst_pts,src_pts, cv2.RANSAC, 5.0)
    dest_point = M @ src_pt.T
    x = np.int64(dest_point[0][1])

@app.route('/', methods=['POST', 'GET'])
def index():
    return render_template('index.html')
    print("page opened", flush=True)
#@socketio.on('img')
@app.route('/upload_image', methods=['POST'])
def img():
    file = request.files['image'] ## byte file
    #return file.filename
    npimg = np.fromstring(file.read(), np.uint8)
    img = cv2.imdecode(npimg,1)
    homo(img)
    #cv2.imshow('image', img)
    #imag = Image.open(file.stream)
    #return "<p>150,35</p>" 
    
if __name__ == '__main__':
    socketio.run(app, port=9990, debug=True)
    
    
    